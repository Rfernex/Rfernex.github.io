# ESCP thesis as a LaTeX paper

Build with `latexmk -xelatex -interaction=nonstopmode -halt-on-error paper.tex`.

The text is in `sections/`, the abstract and acknowledgements have separate files, and all 41 statistical/definition tables are editable LaTeX in `tables/`. References use LaTeX bibliography entries in `references.tex`. No external images, data, or proprietary fonts are required.

This is a typesetting conversion of the May 2023 manuscript. It does not re-estimate results. See the separate conversion notes for source inconsistencies retained for author review.
